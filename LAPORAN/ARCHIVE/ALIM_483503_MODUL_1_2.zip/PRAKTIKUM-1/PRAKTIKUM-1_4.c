#include "MatrixLib.h"

static int A[2][2] = {3,0,8,-1};

int main(){

    print_matrix(2,2,A);
    print_matrix(2,2,I);

    return 0;
}